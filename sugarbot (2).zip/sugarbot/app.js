//curl -X GET "https://graph.facebook.com/v2.6/<USER_ID>?fields=first_name,last_name,profile_pic,locale,timezone,gender&access_token=PAGE_ACCESS_TOKEN"
const express = require("express");//declaramos una variable require es  que va air a buscar la depencia que estamos usando
const Botly = require("botly");//saca libreria
const bodyParser = require('body-parser')
const app = express();//funci�n y mi computadora las trae 
const DecisionTree = require('decision-tree');// una variale que declaramos para ir a buscar 
const newPort = process.env.PORT || 8081//leavanta un servidor , esta variable s ele pasara una variab�e de entorno , y quiero que funcione el 8080 
app.use(bodyParser.json())//middle word , antes de ejecutarse debe de pasar por esa funcion para convertirlas a objetos.
const botly = new Botly({
    accessToken: 'EAACTA01ZCKIUBAF6bHv9PY5Pn6I1fUXQ04xjwB8vhU2GW0ksYQbQ86ZBVlDgLrWMgLPo0lyez0XlnDx9NIr2JZAvbejyrt1ojf9SnHPlceKDZCoeZB5nZAcK49Xrrd3aFL8ZCwYottZAf2e9Pav0D24ba6DeRItzVR3olO20AzJFtAZDZD', //page access token provided by facebook 
    verifyToken: '1138584952912824', //needed when using express - the verification token you provided when defining the webhook in facebook 
    webHookPath: '/', //defaults to "/", 
    notificationType: Botly.CONST.REGULAR //already the default (optional), 
});
var objetoConDatos = {}
var training_data=[
  {"pregunta1":"sidiabetes","edad":"opc1", "familiar": "sifamiliar","estatura": "opc1p4","peso": "opc1p5", "dulces": "opc1p6", "presion": "opc1p7", "alcohol": "opc1p8","fumar": "opc1p8","diagnostico":"Si tienes"},
  {"pregunta1":"nodiabetes","edad":"opc2", "familiar": "sifamiliar","estatura": "opc2p4","peso": "opc2p5", "dulces": "opc1p6", "presion": "opc2p7", "alcohol": "opc2p8","fumar": "opc1p8","diagnostico":"No tienes"}, 
  {"pregunta1":"sidiabetes","edad":"opc3", "familiar": "nofamiliar","estatura": "opc3p4","peso": "opc3p5", "dulces": "opc1p6", "presion": "opc1p7", "alcohol": "opc1p8", "fumar": "opc1p8","diagnostico":"Si tienes"},
  {"pregunta1":"nodiabetes","edad":"opc1", "familiar": "sifamiliar","estatura": "opc1p4","peso": "opc1p5", "dulces": "opc2p6", "presion": "opc2p7", "alcohol": "opc2p8", "fumar": "opc2p8","diagnostico":"Si tienes"},
  {"pregunta1":"sidiabetes","edad":"opc2", "familiar": "sifamiliar","estatura": "opc2p4","peso": "opc2p5", "dulces": "opc2p6", "presion": "opc1p7", "alcohol": "opc1p8", "fumar": "opc2p8","diagnostico":"No tienes"}, 
  {"pregunta1":"nodiabetes","edad":"opc3", "familiar": "nofamiliar","estatura": "opc3p4","peso": "opc3p5", "dulces": "opc2p6", "presion": "opc2p7", "alcohol": "opc2p8", "fumar": "opc2p8","diagnostico":"Si tienes"},
];

var features = ["pregunta1","edad", "familiar", "estatura", "peso", "dulces", "presion", "alcohol", "fumar"];
var class_name = "diagnostico";

var dt = new DecisionTree(training_data, class_name, features);

app.get('/', function(req, res) {// definiendp cuando el navegador esta pidiendo algo, si la dejamos asi es solo la ra�s.res viene en camposulado y send es enviar 
  res.send('Hola');
});

 
botly.on("message", (senderId, message, data) => {// el usuario , es el evento cuando el usuario este mandando un nuevo mensaje.
	console.log(message)
	console.log(data)
	console.log("estoy dentro")
    let text = `echo: ${data.text}`;// concatenar dos cadenas o variables 
 
 //    botly.sendText({id: senderId, text: "Hi There!"}, function (err, data) {
 //    	console.log(data) nos va a mandar informacion , solo le interesa el senderid para identificar que es la persona , message es e� tecto que viene en la parte del  usuario.
	// }); para imprimir en la consola debemos de poner consol log (estoy dentro ejemplo)


	let buttons = [];
	buttons.push(botly.createPostbackButton("Se que tengo diabetes", "sidiabetes"));
	buttons.push(botly.createPostbackButton("Desconozco si tengo diabetes", "nodiabetes"));
 
//	  botly.sendText({id: userId , text : 'Hola soy SugarBot!'} , function(error , data) //ver esto
	botly.sendButtons({id: senderId, text: "Hola soy SugarBot! yo te ayudare a detectar la posiblilidad de tener diabetes por medio de un cuestionario simple o bien ofrecerte tips en caso de ya padecerla... aqu� vamos! Por favor selecciona tu caso", buttons: buttons}, function (err, data) {// esa id , es el idetificador unico que viene de los usuarios , el txt es el texto que se ve en el chat 
	       console.log(data)

	});


});

botly.on("postback", (senderId, message, postback, ref) => {//cuando veas un postback debe de hacer algo.
	console.log(senderId)// la persina que lo esta enviando 
	console.log("postback")// la palabra que recivio y poder direccionar 
	console.log(postback)
	switch (postback){
		//case "sidiabetes":
		case "nodiabetes":

			objetoConDatos.pregunta1 = postback;

		  	let buttons = [];
	       buttons.push(botly.createPostbackButton("Menos de 25 a�os", "opc1"));
	       buttons.push(botly.createPostbackButton("De 25 a 50 a�os", "opc2"));
	       buttons.push(botly.createPostbackButton("Mas de 50 a�os", "opc3")); 
	       botly.sendButtons({id: senderId, text: "Bien, comencemos!. Intenta contestar con la mayor sinceridad posible, una respuesta falsa puede afectar el resultado. Selecciona tu rango de edad", buttons: buttons}, function (err, data) {// esa id , es el idetificador unico que viene de los usuarios , el txt es el texto que se ve en el chat 
	       console.log(data)   
		   });
		
		 // CHECAR �STO POR SI NO SALE BIEN break;
		case "opc1":
		case "opc2":
		case "opc3":

			objetoConDatos.edad = postback;

			let button=[];

			button.push(botly.createPostbackButton("Si", "sifamiliar"));
			button.push(botly.createPostbackButton("No", "nofamiliar"));
			botly.sendButtons({id: senderId, text: "Tienes algun familiar directo que padezca diabetes?", buttons: button}, function (err, data) {// esa id , es el idetificador unico que viene de los usuarios , el txt es el texto que se ve en el chat 
	       console.log(data)   
	       });
	      //ver si va aqi el break
	      break;
	      case "sifamiliar":
	      case "nofamiliar":

	      	objetoConDatos.familiar=postback;

		   	let button2=[];

		   	button2.push(botly.createPostbackButton("Menos de 140 centimetros", "opc1p4"));
		   	button2.push(botly.createPostbackButton("De 141 a 165 centimetros", "opc2p4"));
		   	button2.push(botly.createPostbackButton("Mas de 166 centimetros", "opc3p4"));
			botly.sendButtons({id: senderId, text: "C�al es el rango de tu estatura?", buttons: button2}, function (err, data) {// esa id , es el idetificador unico que viene de los usuarios , el txt es el texto que se ve en el chat 
	       console.log(data)   
	       });

			break;

			case "opc1p4":
			case "opc2p4":
			case "opc3p4":

			objetoConDatos.estatura=postback;

			let button3=[];
			button3.push(botly.createPostbackButton("Menos de 65 kilogramos","opc1p5"));
			button3.push(botly.createPostbackButton("De 66 a 90 kilogramos","opc2p5"));
			button3.push(botly.createPostbackButton("Mas de 91 kilogramos","opc3p5"));
			botly.sendButtons({id: senderId, text: "C�al es el rango de tu peso?", buttons: button3}, function (err, data) {// esa id , es el idetificador unico que viene de los usuarios , el txt es el texto que se ve en el chat 
	       console.log(data)   
	       });
			break;

			case "opc1p5":
			case "opc2p5":
			case "opc3p5":

			objetoConDatos.peso=postback;

			let button4=[];
			button4.push(botly.createPostbackButton("Si","opc1p6"));
			button4.push(botly.createPostbackButton("No","opc2p6"));
			botly.sendButtons({id: senderId, text: "Alguna vez has sentido fuertes ataques de ansiedad por comer dulces?", buttons: button4}, function (err, data) {// esa id , es el idetificador unico que viene de los usuarios , el txt es el texto que se ve en el chat 
	       console.log(data)   
	       });
			break;

			case "opc1p6":
			case "opc2p6":

			objetoConDatos.dulces=postback;

			let button5=[];
			button5.push(botly.createPostbackButton("Si","opc1p7"));
			button5.push(botly.createPostbackButton("No","opc2p7"));
			botly.sendButtons({id: senderId, text: "Alguna vez se te detecto presion alta?", buttons: button5}, function (err, data) {// esa id , es el idetificador unico que viene de los usuarios , el txt es el texto que se ve en el chat 
	       console.log(data)   
	       });
			break;

			case "opc1p7":
			case "opc2p7":

			objetoConDatos.presion=postback;


			let button6=[];
			button6.push(botly.createPostbackButton("Si","opc1p8"));
			button6.push(botly.createPostbackButton("No","opc2p8"));
			botly.sendButtons({id: senderId, text: "Consumes m�s de tres unidades de alcohol diarias?", buttons: button6}, function (err, data) {// esa id , es el idetificador unico que viene de los usuarios , el txt es el texto que se ve en el chat 
	       console.log(data)   
	       });
			break;

			case "opc1p8":
			case "opc2p8":

			objetoConDatos.alcohol=postback;

			let button7=[];
			button7.push(botly.createPostbackButton("Si","opc1p9"));
			button7.push(botly.createPostbackButton("No","opc2p9"));
			botly.sendButtons({id: senderId, text: "Fumas?", buttons: button7}, function (err, data) {// esa id , es el idetificador unico que viene de los usuarios , el txt es el texto que se ve en el chat 
	       console.log(data)   
	       });
			break;

			case "opc1p9":
			case "opc2p9":

			objetoConDatos.fumar=postback;




			var predicted_class = dt.predict(objetoConDatos);	
			console.log(predicted_class)

	    botly.sendText({id: senderId, text: "Tu diagnostico es:"+predicted_class}, function (err, data) {
	    	console.log(data)
		});

		//CHECAR ESTO TAMBIEN
		break; //del nodiabetes
		case "sidiabetes":


		  	let button8 = [];
	       button8.push(botly.createPostbackButton("Ejercicios", "ejercicios"));
	       button8.push(botly.createPostbackButton("Alimentacion", "alimentacion"));
	       button8.push(botly.createPostbackButton("Consultas m�dicas y Salud", "salud")); 
	       botly.sendButtons({id: senderId, text: "Bueno, para adaptarse a la vida con diabetes es recomendable seguir algunos buenos h�bitos, yo te mencionar� algunos", button8: buttons}, function (err, data) {// esa id , es el idetificador unico que viene de los usuarios , el txt es el texto que se ve en el chat 
	       console.log(data)   
		   });
		
		 // CHECAR �STO POR SI NO SALE BIEN
		  break; //del sidiabetes
		  //�STO TAMBI�N!
		case "ejercicios":
			
			 botly.sendText({id: senderId, text: "Para los ejercicios se recomiendan de tres tipos: aerobico, de flexibilidad y entrenamiento de fuerza, puedes comenzar por caminar 10 minutos al d�a e ir aumentando a medida que mejore tu condicion fisica!"}, function (err, data) {
   			console.log(data) 
			 });
		break;
		case "alimentacion":
			botly.sendText({id: senderId, text: "Es importante tener una alimentaci�n saludable, para ello se recomienda tener tiempos espec�ficos de comida, los tiempos son: desayuno, merienda de la ma�ana, almuerzo, merienda de la tarde, cena y merienda de la noche"}, function (err, data) {
   			console.log(data) 
			 });
		break;
		case "salud":
			botly.sendText({id: senderId, text: "En muchos casos para el control de la diabetes se necesita tomar medicamentos, es importante consultar con un m�dico qu� tipo y en qu� medida deben consumirse para su caso, recuerda que no es lo mismo para todas las personas!"}, function (err, data) {
   			console.log(data)
			 });
		break;
		//case "alimentacion":
		//case "salud":

		//	objetoConDatos.edad = postback;


	}


});
 
app.use("/webhook", botly.router());//webhook , es una ruta que le abrimos a facebook 
var server = app.listen(newPort, function () {// configuraci�n general.
        var host = server.address().address;
        var port = server.address().port;

        console.log('Web server started at http://%s:%s', host, port);
});                                                                                                                                                                                                                                                                                                                                                                                                                                   